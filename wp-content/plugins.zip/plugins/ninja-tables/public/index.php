<?php // Silence is golden


